

import java.math.BigInteger;

import static org.junit.Assert.*;

public class PrimeNumbersTest {

    @org.junit.Test()
    public void factorial() {
//        BigInteger[] testValues = {new BigInteger("-1"),new BigInteger("0"), new BigInteger("1"),
//                                    new BigInteger("6"),null};

        //case 2
//        PrimeNumbers.factorial(testValues[2],null);
//        //case 3
//        PrimeNumbers.factorial(null,null);
//        //case 4
//        assertTrue(new BigInteger("720").compareTo(PrimeNumbers.factorial(testValues[3],testValues[2])) == 0);
    }
}