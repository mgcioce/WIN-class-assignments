package util;

public class Quit {

    private boolean quit;

    public Quit(boolean quit) {
        this.quit = quit;
    }

    public boolean getQuit() {
        return this.quit;
    }

    public void setQuit(boolean quit) {
        this.quit = quit;
    }
}
